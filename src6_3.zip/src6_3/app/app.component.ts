import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: 
  `
  <input type = "password">
  <h1>Marvellous Infosystems</h1>
  `,
  styles: 
  [
    `h1
    {color : blue}
    `
  ]
})
export class AppComponent {
  title = 'Project6';
}
