import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent
{
  public str : String = "";
  public Length : number = 0;
  
  public DisplayLength() : any
  {
    this.Length = this.str.length;
  }
  

 

}
