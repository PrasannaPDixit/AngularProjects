import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent 
{
  @Output()
  Myevent = new EventEmitter();

  @Input()
  public cReceive : string = "";

  public cSend :string = "";
  
  public Accept(value : any) : void
  {
    this.cSend = value;
    this.Myevent.emit(this.cSend);
  }



}
