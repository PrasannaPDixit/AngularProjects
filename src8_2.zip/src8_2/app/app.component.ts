import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
  title = 'Project8';
  public pReceive : string = "";
  public pSend : string = "";

  public Accept(value : any) : any
  {
    this.pSend = value;
  }
}
