import { Component } from '@angular/core';
import { ArithmaticService } from '../arithmatic.service';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent 
{
  constructor(public sobj : ArithmaticService) {  }

  public iNo1 : number = 10;
  public iNo2 : number = 11;

  public iRet : number = this.sobj.Add(this.iNo1,this.iNo2);

  public iRet2 : number = this.sobj.Sub(this.iNo1,this.iNo2);

}
