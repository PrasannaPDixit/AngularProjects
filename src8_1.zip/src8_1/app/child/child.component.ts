import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent
{
  @Output()
  public Event = new EventEmitter();

  public Name : string = "";

  public SendData(value : any) : any
  {
    this.Name = value;
    this.Event.emit(this.Name);
  }

  
}
