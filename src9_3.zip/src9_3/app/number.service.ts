import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NumberService 
{
  public CheckPrime(iNo : number) : boolean
  {
    let Flag : boolean = true;
    if(iNo == 2)
    return true;

    for(let i = 2; i <= (iNo/2); i++)
    {
      if(iNo % i == 0)
      {
        Flag = false;
        break;
      }
    }
    return Flag;
  }
}
