import { Component } from '@angular/core';

@Component({
  selector: 'app-new-comp',
  templateUrl: './new-comp.component.html',
  styleUrls: ['./new-comp.component.css']
})
export class NewCompComponent 
{
  public Name : string = "Marvellous";

  public Ret : string = "";
  
  public LowerX() : any
  {
    this.Ret =  this.Name.toLowerCase()
  }

  public UpperX() : any
  {
    this.Ret = this.Name.toUpperCase();
  }

  public DisplayName() : any
  {
    this.Ret = "Name";
  }

  public DisplayFullName() : any
  {
    this.Ret = this.Name + " Infosystems";
  }

}
