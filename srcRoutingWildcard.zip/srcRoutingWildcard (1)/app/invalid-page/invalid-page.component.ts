import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invalid-page',
  templateUrl: './invalid-page.component.html',
})
export class InvalidPageComponent implements OnInit 
{
  constructor() { }
  ngOnInit() {
  }
}
